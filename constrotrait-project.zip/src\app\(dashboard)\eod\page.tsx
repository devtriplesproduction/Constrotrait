import { getAuthenticatedUser } from "@/services/auth.service";
import { getEODHistory, getEODStreak, EODReport, getAllEODs } from "@/services/eod.service";
import { getAllEmployees } from "@/services/employee.service";
import { createClient } from "@/lib/supabase/server";
import { canManageEOD, canReviewEOD } from "@/config/roles";
import { EODSubmissionForm } from "@/components/modules/eod/EODSubmissionForm";
import { ReviewDashboard } from "@/components/modules/eod/ReviewDashboard";
import { CheckCircle2, Clock, ShieldAlert, Send, History, BarChart2 } from "lucide-react";
import { PageHeader } from "@/components/modules/PageHeader";
import Link from "next/link";

interface PageProps {
  searchParams: { tab?: string };
}

export default async function EODPage({ searchParams }: PageProps) {
  const user = await getAuthenticatedUser();
  if (!user) return <div>Unauthorized</div>;

  const supabase = await createClient();
  const { data: profile } = await supabase
    .from('profiles')
    .select('roles, id')
    .eq('id', user.id)
    .single();

  const canReview = canReviewEOD(profile?.roles);
  const canManage = canManageEOD(profile?.roles);
  const isSuperAdmin = profile?.roles?.includes('SUPER_ADMIN');

  // Determine active tab
  const params = await searchParams;
  const activeTab = isSuperAdmin ? 'review' : (canReview ? (params.tab || 'review') : 'submit');

  // --- Fetch Data for Submit Tab ---
  let history: EODReport[] = [];
  let streak = 0;
  let todayEOD: EODReport | undefined;
  let tasksCompleted = 0;
  let hoursLogged = 0;
  let hasBlockers = false;
  type EmployeeOption = { id: string; first_name: string; last_name: string; employee_id: string };
  type EODWithEmployee = EODReport & { profiles: EmployeeOption | null };
  let allEmployees: EmployeeOption[] = [];

  if (activeTab === 'submit') {
    const { data: h } = await getEODHistory(user.id);
    history = (h || []) as EODReport[];
    const { streak: s } = await getEODStreak(user.id);
    streak = s || 0;

    const today = new Date();
    const todayStr = today.toLocaleDateString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit' });
    todayEOD = history.find((h) => {
      const d = new Date(h.report_date);
      return d.toLocaleDateString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit' }) === todayStr;
    });

    tasksCompleted = todayEOD ? todayEOD.tasks_accomplished.split('\n').filter((t: string) => t.trim().length > 0).length : 0;
    hoursLogged = todayEOD ? todayEOD.office_hours : 0;
    hasBlockers = !!(todayEOD && todayEOD.blockers && todayEOD.blockers.trim().length > 0);

    if (canManage) {
      const { data: emps } = await getAllEmployees({ compact: true });
      allEmployees = (emps || []) as EmployeeOption[];
    }
  }

  // --- Fetch Data for Review Tab ---
  let allEODs: EODWithEmployee[] = [];
  let todayReportsCount = 0;

  if (activeTab === 'review' && canReview) {
    const { data: eods } = await getAllEODs();
    allEODs = (eods || []) as EODWithEmployee[];

    if (allEmployees.length === 0) {
      const { data: emps } = await getAllEmployees({ compact: true });
      allEmployees = (emps || []) as EmployeeOption[];
    }

    const todayStr = new Date().toLocaleDateString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit' });
    todayReportsCount = allEODs.filter((e) => {
      const d = new Date(e.report_date);
      return d.toLocaleDateString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit' }) === todayStr;
    }).length;
  }

  return (
    <div className="space-y-6 max-w-[1600px] mx-auto">
      <PageHeader
        title="EOD Reports"
        subtitle={canReview ? "Review team reports or submit your own end-of-day update." : "Submit your daily end-of-day update."}
        actions={
          <div className="flex items-center gap-3">
            {canReview && (
              <div className="flex bg-slate-100 p-1 rounded-xl">
                <Link
                  href="?tab=review"
                  className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center gap-2 ${activeTab === 'review' ? 'bg-orange-600 text-white shadow' : 'text-slate-600 hover:text-slate-800'
                    }`}
                >
                  <BarChart2 className="w-4 h-4" />
                  Review EOD
                </Link>
                {!isSuperAdmin && (
                  <Link
                    href="?tab=submit"
                    className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center gap-2 ${activeTab === 'submit' ? 'bg-orange-600 text-white shadow' : 'text-slate-600 hover:text-slate-800'
                      }`}
                  >
                    <Send className="w-4 h-4" />
                    Submit EOD
                  </Link>
                )}
              </div>
            )}

            {activeTab === 'review' ? (
              <div className="bg-white text-slate-800 px-4 py-2.5 rounded-xl font-semibold border border-slate-200 flex items-center gap-2 shadow-sm">
                <BarChart2 className="w-4 h-4 text-orange-500" />
                <span>{todayReportsCount}</span> <span className="text-slate-500 font-medium">Reports Today</span>
              </div>
            ) : (
              <div className="bg-orange-50 text-orange-700 px-4 py-2 rounded-xl font-semibold border border-orange-100 flex items-center gap-2">
                Current Streak: {streak} days 🔥
              </div>
            )}
          </div>
        }
      />

      {activeTab === 'review' && canReview ? (
        <ReviewDashboard initialEods={allEODs} employees={allEmployees} />
      ) : (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          {/* Left Column: Form */}
          <div className="xl:col-span-7 2xl:col-span-6">
            <EODSubmissionForm employeeId={user.id} canEditDate={canManage} employees={canManage ? allEmployees : undefined} canManage={canManage} />
          </div>

          {/* Right Column: Stats & Logs */}
          <div className="xl:col-span-5 2xl:col-span-6 space-y-6">

            {/* Today at a glance */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
              <div className="flex items-center gap-2 mb-6">
                <div className="w-8 h-8 rounded-lg bg-orange-50 flex items-center justify-center text-orange-600">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" /></svg>
                </div>
                <h2 className="text-lg font-bold text-slate-800">Today at a glance</h2>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-xl border border-slate-100 bg-white shadow-sm flex flex-col justify-between">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-500">
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                    <span className="text-sm font-medium text-slate-500">Tasks Completed</span>
                  </div>
                  <div className="text-3xl font-bold text-slate-800">{tasksCompleted}</div>
                  <div className="mt-1 text-xs text-orange-600 font-medium cursor-pointer hover:underline">View details</div>
                </div>

                <div className="p-4 rounded-xl border border-slate-100 bg-white shadow-sm flex flex-col justify-between">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-8 h-8 rounded-full bg-orange-50 flex items-center justify-center text-orange-500">
                      <Clock className="w-4 h-4" />
                    </div>
                    <span className="text-sm font-medium text-slate-500">Hours Logged</span>
                  </div>
                  <div className="text-3xl font-bold text-slate-800">{hoursLogged}h</div>
                  <div className="mt-1 text-xs text-slate-400 font-medium">Duration</div>
                </div>

                <div className="p-4 rounded-xl border border-slate-100 bg-white shadow-sm flex flex-col justify-between">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-8 h-8 rounded-full bg-amber-50 flex items-center justify-center text-amber-500">
                      <ShieldAlert className="w-4 h-4" />
                    </div>
                    <span className="text-sm font-medium text-slate-500">Blockers</span>
                  </div>
                  <div className="text-3xl font-bold text-slate-800">{hasBlockers ? '1' : '0'}</div>
                  <div className="mt-1 text-xs text-slate-400 font-medium">{hasBlockers ? 'Needs attention' : 'Good to go!'}</div>
                </div>

                <div className="p-4 rounded-xl border border-slate-100 bg-white shadow-sm flex flex-col justify-between">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-8 h-8 rounded-full bg-purple-50 flex items-center justify-center text-purple-500">
                      <Send className="w-4 h-4" />
                    </div>
                    <span className="text-sm font-medium text-slate-500">Status</span>
                  </div>
                  <div className="mb-2">
                    {todayEOD ? (
                      <span className="px-3 py-1 bg-emerald-100 text-emerald-700 text-xs font-bold rounded-full">Submitted</span>
                    ) : (
                      <span className="px-3 py-1 bg-orange-600 text-white text-xs font-bold rounded-full">Not Submitted</span>
                    )}
                  </div>
                  <div className="mt-auto text-xs text-slate-400 font-medium">{todayEOD ? 'Done for the day' : 'Submit to complete'}</div>
                </div>
              </div>
            </div>

            {/* Recent EOD Logs */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[400px]">
              <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-orange-50 flex items-center justify-center text-orange-600">
                    <History className="w-4 h-4" />
                  </div>
                  <h2 className="text-lg font-bold text-slate-800">Recent EOD Logs</h2>
                </div>
                <Link href="#" className="text-sm font-semibold text-orange-600 hover:text-orange-700">View all</Link>
              </div>

              <div className="p-5 overflow-y-auto custom-scrollbar flex-1">
                {history?.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full space-y-3 opacity-80">
                    <div className="w-16 h-16 bg-slate-50 text-slate-400 rounded-full flex items-center justify-center mb-2">
                      <History className="w-8 h-8" />
                    </div>
                    <p className="text-base font-medium text-slate-600">No recent logs</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {history.slice(0, 5).map((eod) => {
                      const eodDate = new Date(eod.report_date);
                      const taskLines = eod.tasks_accomplished.split('\n').filter((t: string) => t.trim().length > 0).length;
                      return (
                        <div key={eod.id} className="flex items-center p-4 rounded-xl border border-slate-100 bg-white shadow-sm hover:shadow-md transition-shadow group">
                          {/* Date Block */}
                          <div className="flex flex-col items-center justify-center min-w-[50px] mr-4 text-orange-600 font-bold leading-tight">
                            <span className="text-xl">{eodDate.getDate()}</span>
                            <span className="text-[10px] uppercase tracking-wider">{eodDate.toLocaleString('default', { month: 'short' })}</span>
                          </div>

                          {/* Details */}
                          <div className="flex-1 min-w-0">
                            <h4 className="text-sm font-bold text-slate-800 truncate">
                              {eodDate.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                            </h4>
                            <p className="text-xs text-slate-500 mt-0.5">
                              {taskLines} tasks &bull; {eod.office_hours}h logged
                            </p>
                          </div>

                          {/* Status Badge */}
                          <div className="ml-3 flex-shrink-0 flex items-center gap-3">
                            <span className={`px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider rounded-full border flex items-center gap-1 ${eod.status === 'Approved' ? 'bg-emerald-50 text-emerald-600 border-emerald-200' :
                              eod.status === 'Rejected' ? 'bg-rose-50 text-rose-600 border-rose-200' :
                                'bg-amber-50 text-amber-600 border-amber-200'
                              }`}>
                              {eod.status === 'Approved' && <CheckCircle2 className="w-3 h-3" />}
                              {eod.status === 'Pending' && <Clock className="w-3 h-3" />}
                              {eod.status}
                            </span>
                            <svg className="w-4 h-4 text-slate-300 group-hover:text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
